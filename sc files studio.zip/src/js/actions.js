function addTeam(name, context) {
    addAction({
        type: "add_team",
        payload: {
            name: name
        }
    }, context);
}

function renameTeam(id, newName, context){
    addAction({
        type: "rename_team",
        payload: {
            id: id,
            name: newName
        }
    }, context);
}

function removeTeam(id, context){
    addAction({
        type: "remove_team",
        payload: {
            id: id
        }
    }, context);
}

function toSettings(context) {
    addAction({
        type: "go_to_settings"
    }, context);
}

function toGame(context) {
    addAction({
        type: "go_to_game"
    }, context);
}

function turnOnCLW(context) {
    addAction({
        type: "turn_on_clw"
    }, context);
}

function turnOffCLW(context) {
    addAction({
        type: "turn_off_clw"
    }, context);
}

function turnOnPenalty(context) {
    addAction({
        type: "turn_on_penalty"
    }, context);
}

function turnOffPenalty(context) {
    addAction({
        type: "turn_off_penalty"
    }, context);
}

function setDuration(value, context) {
    addAction({
        type: "set_duration",
        payload: {
            value: value
        }
    }, context);
}

function setNumberOfWords(value, context) {
    addAction({
        type: "set_number_of_words",
        payload: {
            value: value
        }
    }, context);
}

function goBack(context) {
    addAction({
        type: "go_back"
    }, context);
}

function startOver(context) {
    addAction({
        type: "start_over"
    }, context);
}

function goRules(context) {
    addAction({
        type: "go_to_rules"
    }, context);
}